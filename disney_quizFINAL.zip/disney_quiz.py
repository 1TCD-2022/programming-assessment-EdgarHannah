"""
Filename: DISNEY_QUIZ
Author: Hannah
Date: 30/6/22
Description: this program will run a true or false quiz that tests the users
knowledge on disney movies.
"""
import random


def finish():
    # this will end the program a nice way
    print("Hope you enjoyed using this program.\nHave a nice day.")


def play_user_quiz(user_questions):
    # this function will allow the user to play the quiz they made
    # only liked to the user_quiz

    user_questions
    TRUE_OR_FALSE = ["T", "t", "F", "f", "X", "x"]
    try_again = ["Y", "N"]
    retry = ""

    # this makes the code loop depending on the users input
    while retry != "N":

        score = 0
        count = 0
        user_quiz = user_questions.copy()

        print("""to answer this quiz please type in either
    T : true
    F : false
you can use both capitals and lowercase\n""")

        # this makes sure only ten questions are printed
        # it also ensures that the program won't crash if less then ten added
        num_questions = len(list(user_quiz.keys()))
        if num_questions >= 10:
            num_questions = 10
        for i in range(num_questions):

            # getting a random question from the ditionarY
            # and the corrasponding answer
            rand_q = random.choice(list(user_quiz.keys()))
            rand_q_answer = user_quiz[rand_q]
            user_input = input("{}? ".format(rand_q)).upper()
            count += 1

            # these loops vaildate the answer
            # make sure the user is putting in the correct input
            while user_input not in TRUE_OR_FALSE:
                print("that is not one of the options, please enter t or f")
                user_input = input("{}? ".format(rand_q)).upper()

            if user_input == rand_q_answer:
                print ("Correct!\n")
                score += 1
                del user_quiz[rand_q]

            else:
                print ("""Incorrect Answer your answer was {}, the correct answer is {}\n
                """.format(user_input, rand_q_answer))
                del user_quiz[rand_q]

        # loop to either stop or repeat the quiz
        print("you got {} out of {} correct!".format(score, count))
        finished_retry = False
        retry = input("""If you would like to retry this quiz press Y otherwise press N
""").upper()
        while retry not in try_again and not finished_retry:
            if retry == "Y":
                finished_retry = True
            elif retry == "N":
                finished_retry = True
            else:
                retry = input("""If you would like to retry this quiz press Y otherwise press N
""").upper()


def do_user_quiz(menu, menu_selection, user_quizzes):
    menu
    menu_selection
    user_quizzes
    menu_item = list(menu.keys())[menu_selection - 1].replace("Play ", "")

    selected_quiz = user_quizzes[menu_item]
    # play the quiz
    play_user_quiz(selected_quiz)
    return menu, user_quizzes


def create_quiz(menu, menu_selection, user_quizzes):
    # call this function when you play the quiz
    # this function will allow the user to
    # make their own quiz with 10 questions

    menu
    menu_selection
    user_quizzes
    user_questions = {}
    TRUE_OR_FALSE = ["T", "F"]
    count = 0
    USER_CHOICE = ["1", "2", "3"]

    menu_keys = menu.keys()
    quiz_name = input("give your quiz a name: ")
    # if list(menu_keys.len() > 2:
    # del menu[menu_keys.index(3)]
    menu["Play " + quiz_name] = "do_user_quiz"

    print("""please enter your own questions and frame them to be either
True (t) or False (f).\n""")

    print("please enter ten questions below.\n")

    # this allows the user to enter 10 questions
    while count < 10:
        question = input("Enter a question: ")
        answer = input("T or F? ").upper()

        while answer not in TRUE_OR_FALSE:
            print("please enter either a T or F")
            answer = input("T or F? ").upper()

        count += 1
        user_questions[question] = answer
        print("you have added {} questions".format(count))

    user_quizzes[quiz_name] = user_questions
    # print(menu)
    return menu, user_quizzes


def disney_quiz(menu, menu_selection, user_quizzes):
    # this function will allow the user to try a true or false disney quiz
    # score will be printed at the end as well
    # this dictionary holds all of the questions and answers in my code

    retry = ""
    TRUE_OR_FALSE = ["T", "t", "f", "F", "X", "x"]
    try_again = ["Y", "N"]

    questions = {
        "Mickey mouse was originally going to be called Michael Mouse? ": "F",
        "Snow white was the first disney princess? ": "T",
        """Animators have hidden the easter egg “A113”
in all but one pixar film? """: "F",
        """Cinderella, Belle, and Tiana wear gloves
to signify that they married into royalty? """: "T",
        "Geppetto is Peter Pan’s dad? ": "F",
        "Pascal and Maximus are the horses in Cinderella? ": "F",
        "Mulan is set in Japan? ": "F",
        """Pocahontas is the only Disney princess
based on a real life person? """: "T",
        "Disney’s first original character was a rabbit? ": "T",
        "The army Mulan fights is called the Huns? ": "T"
         }
    while retry != "N":

        disney_quiz = questions.copy()
        score = 0
        count = 0
        user_input = ""

        print("""to answer this quiz please type in either
    T : true
    F : false
you can use both capitals and lowercase\n""")
        for i in range(10):
            # getting a random question from the ditionary
            # and the corrasponding answer
            rand_q = random.choice(list(disney_quiz.keys()))
            rand_q_answer = disney_quiz[rand_q]
            user_input = input("{}".format(rand_q)).upper()
            count += 1

            while user_input not in TRUE_OR_FALSE:
                print("that is not one of the options, please enter t or f")
                user_input = input("{}".format(rand_q)).upper()

            if user_input == rand_q_answer:
                print ("Correct!\n")
                del disney_quiz[rand_q]
                score += 1
            else:
                print ("""Incorrect Answer your answer was {}, the correct answer is {}
\n""".format(user_input, rand_q_answer))
                del disney_quiz[rand_q]

        # after the for loop finishes this gives the user their score
        print("you got {} out of {} correct!\n".format(score, count))
        finished_retry = False
        while not finished_retry:
            retry = input("""If you would like to retry this quiz press Y otherwise press N
""").upper()
            if retry == "Y":
                finished_retry = True

            elif retry == "N":
                finished_retry = True

            else:
                retry = input("""If you would like to retry this quiz press Y otherwise press N
""").upper()

    return menu, user_quizzes


def main():
    # this will have the main menu with all of the choices
    # and tell the user what this code does
    # print("this is my quiz program, please choose an option\n")
    print("welcome to my quiz program. plaese choose one of the options below.")
    menu = {
        "Do disney quiz": "disney_quiz",
        "Build Own quiz": "create_quiz"
        }

    user_quizzes = {}

    user_quit = False
    while user_quit is False:
        # Print the menu
        count = 0
        menu_list = list(menu.keys())
        while count < len(menu_list):
            print("{} : {}".format(count + 1, menu_list[count]))
            count += 1
        # Add quit as the last option
        print ("{} : quit".format(count + 1))
        # print(count)
        # get user input and do the action
        valid_action = False
        while valid_action is False:
            valid_input = False
            menu_selection = 0
            user_typed = input("what option would you like? ")
            while not valid_input:
                try:
                    menu_selection = int(user_typed)
                    valid_input = True
                except ValueError:
                    user_typed = input("""please enter a number.
what option would you like? """)

            if menu_selection > 0 and menu_selection <= len(menu_list):
                menu_item = menu[menu_list[menu_selection - 1]]
                # print(menu_item)
                func = globals()[menu_item]
                menu, user_quizzes = func(menu, menu_selection, user_quizzes)
                # locals()[menu_item](menu, menu_selection, user_quizzes)
                # print("finished {}".format(menu_item))
                valid_action = True
            elif menu_selection == len(menu_list) + 1:
                valid_action = True
                user_quit = True
            else:
                print("that input is invaild")
    finish()

main()
