"""
Filename: DISNEY_QUIZ
Author: Hannah
Date: 30/6/22
Description: this program will run a true or false quiz that tests the users
knowledge on disney movies.
"""

import random

def play_user_quiz(user_questions):
    #this function will allow the user to play the quiz they made
    #only liked to the user_quiz

    user_questions
    TRUE_OR_FALSE = ["T","t","F","f","X","x"]
    try_again = ["YES","Y"]
    retry = True

    #this makes the code loop depending on the users input
    while retry == True:
        
        score = 0
        count = 0
        user_quiz = user_questions.copy()
        
        print("Please enter either t or f in accordance to what you think the right answer is\n")

        #this makes sure only ten questions are printed 
        for i in range(10):
            
            #getting a random question from the ditionary and the corrasponding answer
            rand_q = random.choice(list(user_quiz.keys()))
            rand_q_answer = user_quiz[rand_q]
            user_input = input("{}? ".format(rand_q)).upper()
            count += 1

            #these loops vaildate the answer and make sure the user is putting in the correct input 
            while user_input not in TRUE_OR_FALSE:
                print("that is not one of the options, please enter t or f")
                user_input = input("{}? ".format(rand_q)).upper()
                 
            if user_input == rand_q_answer:
                print ("Correct!")
                score += 1
                del user_quiz[rand_q]
                 
            else:
                print ("Incorrect Answer your answer was {}, the correct answer is {}".format(user_input, rand_q_answer))
                del user_quiz[rand_q]

        #loop to either stop or repeat the quiz
        print("you got {} out of {} correct!".format(score,count))
        retry = input("would you like to play again? ").upper()
        if retry in try_again:
            retry = True 
        else:
            retry = False
    play_again()

def user_quiz():
    #this function will allow the user to make their own quiz with 10 questions
    
    user_questions = {}
    TRUE_OR_FALSE = ["T","F"]
    count = 0
    USER_CHOICE = ["1","2","3"]
    
    print("""Welcome to the user quiz.\nIn this quiz you will be able to input your own T or F
questions so you can make your own quiz.\nHope you enjoy.\n""")
    
    print("please enter ten questions below.\n")

    #this allows the user to enter 10 questions 
    while count < 10:
        question = input("Enter a question: ")
        answer = input("T or F? ").upper()
            
        while answer not in TRUE_OR_FALSE:
            print("please enter either a T or F")
            answer = input("T or F? ").upper()
                
        count += 1
        user_questions[question] = answer
        print("you have added {} questions".format(count))
    
    play_quiz = input("""would you like to:
    1. play your quiz
    2. Return to main menu
    3. Quit\n""")

    while play_quiz not in USER_CHOICE:
        try:
            retry = input("""would you like to
    1. play your quiz
    2. Return to main menu
    3. Quit\n""")
        except ValueError:
            print("Please enter a number")
        play_quiz = input("""would you like to:
    1. play your quiz
    2. Return to main menu
    3. Quit\n""")
        
    if play_quiz == "1":
        play_user_quiz(user_questions)
    elif play_quiz == "2":
        main_menu()
    else:
        finish()
    return user_questions
        
    
def play_again():
    #this function will allow the users to have the choice of if they want to try
    #the quiz again, go back to the menu, or quit
    
    USER_CHOICES = ["1","2","3","4"]
    
    print("Hope you enjoyed this quiz. please choose one of the options down below.")
    retry = input("""would you like to:
    1.Play the disney quiz
    2.Make a quiz
    3.Return to main menu
    4.Quit\n""")

    while retry not in USER_CHOICES:
        try:
            retry = input("""would you like to
    1.Play the disney quiz
    2.Make a quiz
    3.Return to main menu
    4.Quit\n""")
        except ValueError:
            print("Please enter a number")
        retry = input("""would you like to
    1.Play the disney quiz
    2.Make a quiz
    3.Return to main menu
    4.Quit\n""")
        
    if retry == "1":
        disney_quiz()
    elif retry == "2":
        user_quiz()
    elif retry == "3":
        main_menu()
    else:
        finish()


def finish():
    #this will end the program a nice way
    print("Hope you enjoyed using this program.\nHave a nice day.")


def disney_quiz():
    #this function will allow the user to try a true or false disney quiz
    #score will be printed at the end as well
    #this dictionary holds all of the questions and answers in my code

    retry = True
    TRUE_OR_FALSE = ["T","t","f","F","X","x"]
    try_again = ["Y","YES"]
    
    questions = {
        "Mickey mouse was originally going to be called Michael Mouse? ":"F",
        "Snow white was the first disney princess? ":"T",
        "Animators have hidden the easter egg “A113” in all but one pixar film? ":"F",
        "Cinderella, Belle, and Tiana wear gloves to signify that they married into royalty? ":"T",
        "Geppetto is Peter Pan’s dad? ":"F",
        "Pascal and Maximus are the horses in Cinderella? ":"F",
        "Mulan is set in Japan? ":"F",
        "Pocahontas is the only Disney princess based on a real life person? ":"T",
        "Disney’s first original character was a rabbit? ":"T",
        "The army Mulan fights is called the Huns? ":"T"
         }
    while retry == True:

        disney_quiz = questions.copy()
        score = 0
        count = 0
        user_input = ""

        print("Please enter either t or f in accordance to what you think the right answer is\n")
        for i in range (10):
            
             #getting a random question from the ditionary and the corrasponding answer   
             rand_q = random.choice(list(disney_quiz.keys()))
             rand_q_answer = disney_quiz[rand_q]
             user_input = input("{}".format(rand_q)).upper()
             count += 1
             
             while user_input not in TRUE_OR_FALSE:
                 print("that is not one of the options, please enter t or f")
                 user_input = input("{}".format(rand_q)).upper()
                 
             if user_input == rand_q_answer:
                 print ("Correct!\n")
                 del disney_quiz[rand_q]
                 score += 1
                 
             else:
                 print ("Incorrect Answer your answer was {}, the correct answer is {}\n".format(user_input, rand_q_answer))
                 del disney_quiz[rand_q]

        #after the for loop finishes this gives the user their score 
        print("you got {} out of {} correct!\n".format(score,count))
        retry = input("would you like to play again? (if yes press y) ").upper()
        if retry in try_again:
            retry = True 
        else:
            retry = False
    play_again()

def main_menu():
    #this will have the main menu with all of the choices
    #and tell the user what this code does  
    
    USER_MENU_CHOICES = ["1", "2", "3"]
    user_choice = ""

    print("""Welcome to my Quiz program, here are some things you can do:
    1. Disney T/F quiz
    2. Make your own Quiz
    3. Quit\n""")

    user_choice = input("what option would you like: ")

    while user_choice not in USER_MENU_CHOICES:
        try:
            user_choice = input("what option would you like: ")
        except ValueError:
            print("Please enter a number")
        user_choice = input("what option would you like: ")

    if user_choice == "1":
        disney_quiz()
    elif user_choice == "2":
        user_quiz()
    else:
        finish()

main_menu()
