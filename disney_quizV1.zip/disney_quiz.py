"""
Filename: DISNEY_QUIZ
Author: Hannah
Date: 30/6/22
Description: this program will run a true or false quiz that tests the users
knowledge on disney movies.
"""

import random
"""
def play_user_quiz():
#this function will allow the user to play the quiz they made
#only will be liked to user_quiz
    
def user_quiz():
#this function will allow the user to make their own quiz with 5 questions   
"""


def play_again():
    #this function will allow the users to have the choice of if they want to try
    #the quiz again, go back to the menu, or quit
    USER_CHOICE
    print("Hope you enjoyed this quiz. please choose one of the options down below.")
    retry = input("""would you like to
    1.Play again
    2.Back to main menu
    3.Quit\n""")

    while retry not in USER_CHOICES:
        try:
            retry = input("""would you like to
    1.Play again
    2.Back to main menu
    3.Quit\n""")
        except ValueError:
            print("Please enter a number")
        retry = input("""would you like to
    1.Play again
    2.Back to main menu
    3.Quit\n""")
        
    if retry == "1":
        disney_quiz()
    elif retry == "2":
        main_menu()
    else:
        finish()


def finish():
    #this will end the program a nice way
    print("Hope you enjoyed using this program.\nHave a nice day.")


def disney_quiz():
    #this function will allow the user to try a true or false disney quiz
    #score will be printed at the end as well
    #this dictionary holds all of the questions and answers in my code
    
    Questions = {
        "Mickey mouse was originally going to be called Michael Mouse ":"F",
        "Snow white was the first disney princess ":"T",
        "Animators have hidden the easter egg “A113” in all but one pixar film ":"F",
        "Cinderella, Belle, and Tiana wear gloves to signify that they married into royalty ":"T",
        "Geppetto is Peter Pan’s dad ":"F",
        "Pascal and Maximus are the horses in Cinderella ":"F",
        "Mulan is set in Japan ":"F",
        "Pocahontas is the only Disney princess based on a real life person ":"T",
        "Disney’s first original character was a rabbit ":"T",
        "The army Mulan fights is called the Huns ":"T"
         }
    user_input = ""

    print("Please enter either t or f in accordance to what you think the right answer is\nYou may quit this any time by pressing x")
    while user_input != "X":

         #getting a random question from the ditionary and the corrasponding answer
         rand_q = random.choice(list(Questions.keys()))
         rand_q_answer = Questions[rand_q]
         user_input = input("{}".format(rand_q)).upper()

         if user_input == rand_q_answer:
             print ("Correct!")
         elif user_input == "X":
             play_again()
         else:
             print ("Incorrect Answer your answer was {}, the correct answer is {}".format(user_input, rand_q_answer))
    

def main_menu():
    #this will have the main menu with all of the choices and tell the user what this code does
    USER_MENU_CHOICES = ["1", "2", "3"]
    user_choice = ""

    print("""Welcome to my Quiz program, here are some things you can do:
    1. Disney T/F quiz
    2. Make your own Quiz
    3.Quit\n""")

    user_choice = input("what option would you like: ")
    while user_choice not in USER_MENU_CHOICES:
        try:
            user_choice = input("what option would you like: ")
        except ValueError:
            print("Please enter a number")
        user_choice = input("what option would you like: ")

    if user_choice == "1":
        disney_quiz()
    elif user_choice == "2":
        print("user_quiz")
    else:
        finish()

main_menu()
